<h2>Panel Dokter </h2>

<!-- <pre> -->
  <?php // print_r($_SESSION); ?>
<!-- </pre> -->

<style>
  @import url('https://fonts.googleapis.com/css2?family=Protest+Riot&display=swap');
  h2{
    font-family: "Protest Riot", sans-serif;
    font-size: 50px;
    font-weight: 18;
  }
</style>